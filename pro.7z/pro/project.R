BMI<-read.csv("HW.csv")
print(BMI)
head(BMI)
tail(BMI)
# corelation
library("ggpubr")
ggscatter(BMI, x = "Height", y = "Weight", 
          add = "reg.line", conf.int = TRUE, 
          cor.coef = TRUE, cor.method = "pearson",
          xlab = "Height(cm)", ylab = "Weight (kg)")

#Shapiro-Wilk normality test for Height
shapiro.test(BMI$Height)
#Shapiro-Wilk normality test for wt
shapiro.test(BMI$Weight)
#Visual inspection of the data normality using Q-Q plots (quantile-quantile plots).
#Q-Q plot draws the correlation between a given sample and the normal distribution.
ggqqplot(BMI$Weight, ylab = "Weight")
ggqqplot(BMI$Height, ylab = "Height")
#pearson
res <- cor.test(BMI$Weight, BMI$Height, method = "pearson")
res
res$p.value
res$estimate
#kendall
res2 <- cor.test(BMI$Weight, BMI$Height, method = "kendall")
res2
res3 <- cor.test(BMI$Weight, BMI$Height, method = "spearman")
res3
#
#library(ggplot2)
#library(ggpubr)
#theme_set(theme_pubr())
#ggplot(BMI, aes(x = Hair, y = Freq))+
 # geom_bar(
  #  aes(fill = Eye), stat = "identity", color = "white",
   # position = position_dodge(0.9)
  #)+

  #facet_wrap(~Sex) + 
  #fill_palette("jco")
install.packages("rgl")
install.packages("scatterplot3d") # Install
library("scatterplot3d")
head(BMI)
scatterplot3d(BMI[,1:3])
scatterplot3d(BMI[,1:3], angle = 55)
scatterplot3d(BMI[,1:3],
              main="3D Scatter Plot",
              xlab = "Sepal Height (cm)",
              ylab = "Sepal Weight(kg)",
              zlab = "Petal Index (cm)")
#################################

summary(BMI)
summary(BMI$Index)
summary(BMI$Gender)
install.packages("dplyr")
library('dplyr')
head(select(BMI, Gender, Index))
filter(BMI, Index==0)
filter(BMI,Index==1)
filter(BMI, Index==2)
filter(BMI, Index==3)
filter(BMI, Index==4)
filter(BMI, Index==5)
BMI %>% arrange(Height) %>% head
BMI %>% arrange(Index)
BMI %>% arrange(Gender) %>% head
BMI %>% arrange(Weight) %>% head

BMI %>% 
  mutate(Status = Index) %>%
  head
BMI %>%  summarise(total = n())
#############

#BMI %>% 
 # mutate(Status = )%>%
  #head


  